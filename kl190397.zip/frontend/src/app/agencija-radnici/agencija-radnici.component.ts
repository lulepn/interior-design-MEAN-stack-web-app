import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agencija-radnici',
  templateUrl: './agencija-radnici.component.html',
  styleUrls: ['./agencija-radnici.component.css']
})
export class AgencijaRadniciComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
