export class Posao {
    usernameObj : string;
    adresaObj : string;
    datumOd : Date;
    datumDo : Date;
    ugovorenaCena : number;
    agencija : string;
    zavrsen : number;
    prostorija1status : number;
    prostorija2status : number;
    prostorija3status : number;
    brojRadnika : number;
}