export class Zahtev {
    usernameObj : string;
    adresaObj : string;
    datumOd : Date;
    datumDo : Date;
    ponuda : number;
    agencija : string;
    prihvacen : number;
}