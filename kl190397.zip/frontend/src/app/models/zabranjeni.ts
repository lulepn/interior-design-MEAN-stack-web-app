export class Zabranjeni {
    username : string;
    email : string;
}