export class RadnaMesta {
    agencija : string;
    broj : number;
}