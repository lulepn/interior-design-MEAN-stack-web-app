export class Admin {
    username: String;
    password: String;
}