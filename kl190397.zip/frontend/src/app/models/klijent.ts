export class Klijent {
    username: String;
    password: String;
    telefon: String;
    email: String;
    ime : String;
    prezime : String;
    imageSrc : String;
    registrovan : number;
}