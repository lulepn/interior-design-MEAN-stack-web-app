export class User {
    username : String;
    password : String;
    registrovan : number;
}