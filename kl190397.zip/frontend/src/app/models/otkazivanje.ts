export class Otkazivanje {
    agencija : string;
    usernameObj : string;
    adresaObj : string;
}