export class Radnik {
    telefon: String;
    email: String;
    ime : String;
    prezime : String;
    specijalizacija : String;
    agencija : String;
}