export class Prostorija {
    duzina : number;
    sirina : number;
    startX : number;
    startY : number;
}

