export class Vrata {
    orijentacija : number;
    sirina : number;
    startX : number;
    startY : number;
}