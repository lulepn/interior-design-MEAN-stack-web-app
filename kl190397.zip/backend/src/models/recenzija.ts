export class Recenzija {
    ocena : number;
    komentar : string;
    klijent : string;
}